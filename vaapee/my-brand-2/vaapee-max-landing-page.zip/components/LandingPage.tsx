import React, { useState } from 'react';
import { ArrowRight, Zap, Wind, Palette } from 'lucide-react';

const COLORS = {
  green: '#C4F135',
  orange: '#FF5C00',
  purple: '#8B5CF6',
  black: '#000000',
  white: '#ffffff',
};

const LandingPage: React.FC = () => {
  return (
    <div className="w-full bg-white text-black overflow-hidden relative selection:bg-[#C4F135] selection:text-black">
      {/* Navbar / Brand Header */}
      <header className="fixed top-0 left-0 w-full z-50 p-4 mix-blend-hard-light pointer-events-none">
         <div className="flex justify-between items-center max-w-7xl mx-auto">
            <h1 className="font-russo text-4xl italic tracking-tighter text-black pointer-events-auto drop-shadow-[2px_2px_0px_rgba(255,255,255,1)]">
              VAAPEE
            </h1>
         </div>
      </header>

      {/* 1. HERO SECTION */}
      <section className="relative min-h-screen flex flex-col items-center justify-center pt-20 pb-12 px-4 border-b-4 border-black">
        {/* Decorative Background Elements */}
        <div className="absolute top-1/4 left-10 w-24 h-24 bg-[#C4F135] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] rotate-12 hidden md:block animate-bounce duration-1000"></div>
        <div className="absolute bottom-1/4 right-10 w-32 h-32 bg-[#FF5C00] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] -rotate-6 rounded-full hidden md:block"></div>
        
        <div className="max-w-7xl w-full mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
          
          {/* Text Content */}
          <div className="flex flex-col gap-6 text-center lg:text-left">
            <div className="inline-block mx-auto lg:mx-0 bg-black text-white px-4 py-2 font-russo transform -skew-x-12 border-2 border-[#C4F135] shadow-[4px_4px_0px_0px_#C4F135]">
              <span className="skew-x-12 inline-block uppercase tracking-widest text-sm md:text-base">New Release 2024</span>
            </div>
            
            <h2 className="font-russo text-6xl md:text-8xl lg:text-9xl leading-[0.9] uppercase italic tracking-tighter">
              <span className="block text-black drop-shadow-[4px_4px_0px_#C4F135]">Max</span>
              <span className="block text-transparent text-stroke-lg md:text-stroke-lg text-[#FF5C00]">Power.</span>
              <span className="block text-black">Max</span>
              <span className="block text-transparent text-stroke-lg md:text-stroke-lg text-[#8B5CF6]">Puffs.</span>
              <span className="block text-black bg-[#C4F135] inline px-2 transform -skew-x-6 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] mt-4">
                Max Chaos.
              </span>
            </h2>
            
            <p className="font-bold text-lg md:text-xl max-w-md mx-auto lg:mx-0 mt-6 border-l-4 border-black pl-4">
              The ultimate vaping experience. Engineered for the bold. Designed for the streets.
            </p>
          </div>

          {/* Product Placeholder */}
          <div className="relative group perspective-1000">
             <div className="relative z-10 w-full max-w-sm mx-auto aspect-[3/4] bg-white border-4 border-black shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] flex items-center justify-center overflow-hidden transition-transform duration-300 group-hover:-translate-y-2 group-hover:translate-x-2 group-hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]">
                <img 
                  src="https://picsum.photos/600/800?grayscale" 
                  alt="VAAPEE MAX Product" 
                  className="object-cover w-full h-full mix-blend-multiply opacity-90 group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <span className="font-russo text-5xl text-white opacity-80 rotate-[-45deg] drop-shadow-md text-stroke">PRODUCT<br/>PLACEHOLDER</span>
                </div>
                
                {/* Sticker Effect */}
                <div className="absolute top-4 right-4 bg-[#FF5C00] text-white font-russo px-3 py-1 text-xl border-4 border-black rotate-12 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  NEW!
                </div>
             </div>
             
             {/* Backsplash Graphic */}
             <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-[#8B5CF6] rounded-full filter blur-3xl opacity-20"></div>
          </div>
        </div>
      </section>

      {/* 2. FEATURES SECTION */}
      <section className="py-20 px-4 bg-white relative">
         {/* Marquee effect background (Simulated) */}
         <div className="absolute top-0 left-0 w-full overflow-hidden whitespace-nowrap opacity-5 pointer-events-none">
            <span className="text-[200px] font-russo leading-none">VAAPEE MAX VAAPEE MAX VAAPEE MAX</span>
         </div>

         <div className="max-w-7xl mx-auto">
            <h3 className="text-5xl md:text-7xl font-russo text-center mb-16 uppercase italic">
              <span className="inline-block border-b-8 border-[#C4F135]">Dominate</span> The Game
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-4 lg:gap-12">
               {/* Feature 1 */}
               <FeatureCard 
                  color="bg-[#C4F135]"
                  icon={<Wind size={48} strokeWidth={2.5} />}
                  title="15,000 Puffs"
                  slogan="Never Stop"
                  description="Massive capacity tank designed to outlast your wildest weekends."
               />
               
               {/* Feature 2 */}
               <FeatureCard 
                  color="bg-[#FF5C00]"
                  icon={<Zap size={48} strokeWidth={2.5} />}
                  title="Ceramic Coil"
                  slogan="Pure Flavor Tech"
                  description="Aerospace-grade ceramic heating for instant, pure taste delivery."
               />

               {/* Feature 3 */}
               <FeatureCard 
                  color="bg-[#8B5CF6]"
                  icon={<Palette size={48} strokeWidth={2.5} />}
                  title="RGB Custom"
                  slogan="Light Up Your Vibe"
                  description="Fully customizable LED array. Match your vape to your fit."
               />
            </div>
         </div>
      </section>

      {/* 3. CTA SECTION */}
      <section className="py-24 px-4 bg-black text-white border-y-4 border-black relative overflow-hidden">
         {/* Grid Pattern */}
         <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(#444 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>

         <div className="max-w-4xl mx-auto text-center relative z-10 flex flex-col items-center gap-8">
            <h2 className="font-russo text-6xl md:text-8xl text-[#C4F135] text-stroke-sm uppercase leading-none transform -skew-x-6">
              Ready to <br/><span className="text-white text-stroke-none">Max Out?</span>
            </h2>
            
            <p className="font-kanit text-xl md:text-2xl max-w-2xl text-gray-300">
               Limited pre-order stock available. Don't sleep on the drop.
            </p>

            <button className="group relative inline-flex items-center justify-center gap-4 bg-[#C4F135] text-black font-russo text-3xl md:text-4xl py-6 px-12 border-4 border-white transition-all duration-200 
              shadow-[12px_12px_0px_0px_#8B5CF6] 
              hover:translate-x-[6px] hover:translate-y-[6px] 
              hover:shadow-[6px_6px_0px_0px_#8B5CF6]
              active:translate-x-[12px] active:translate-y-[12px] active:shadow-none
            ">
               <span className="uppercase tracking-wide">Pre-Order Now</span>
               <ArrowRight className="w-8 h-8 md:w-10 md:h-10 transition-transform group-hover:translate-x-2" strokeWidth={3} />
            </button>
         </div>
      </section>

      {/* 4. FOOTER */}
      <footer className="bg-white pt-16 pb-8 px-4 border-t-4 border-black">
         <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-end gap-8 mb-12">
            <div>
               <h2 className="font-russo text-6xl text-black tracking-tighter mb-4">VAAPEE</h2>
               <div className="flex gap-4 font-bold text-lg">
                  <a href="#" className="hover:bg-black hover:text-white px-2 transition-colors">INSTAGRAM</a>
                  <a href="#" className="hover:bg-black hover:text-white px-2 transition-colors">TIKTOK</a>
                  <a href="#" className="hover:bg-black hover:text-white px-2 transition-colors">SUPPORT</a>
               </div>
            </div>
            <div className="text-right">
               <p className="font-bold text-xl mb-2">© 2024 VAAPEE LABS INC.</p>
               <p className="text-sm font-medium text-gray-500">DESIGNED FOR CHAOS.</p>
            </div>
         </div>

         {/* DISCLAIMER BANNER */}
         <div className="w-full bg-black p-6 border-4 border-gray-200">
            <div className="flex flex-col items-center justify-center text-center gap-2">
               <p className="text-white font-bold text-xl md:text-2xl uppercase font-russo tracking-wide">
                  WARNING: This product contains nicotine. Nicotine is an addictive chemical.
               </p>
               <p className="text-[#C4F135] font-bold text-lg md:text-xl font-kanit">
                  警告：本产品含有尼古丁。尼古丁是成瘾性化学品。
               </p>
            </div>
         </div>
      </footer>
    </div>
  );
};

// Sub-component for Feature Cards
interface FeatureCardProps {
  color: string;
  icon: React.ReactNode;
  title: string;
  slogan: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ color, icon, title, slogan, description }) => {
  return (
    <div className={`
      relative p-8 border-4 border-black 
      ${color} 
      shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] 
      transition-all duration-300 
      hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] 
      hover:translate-x-[6px] hover:translate-y-[6px]
      flex flex-col gap-4 group
    `}>
      <div className="w-16 h-16 bg-white border-4 border-black flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mb-2">
        {icon}
      </div>
      
      <div>
        <h4 className="font-kanit font-black uppercase text-sm tracking-widest mb-1 opacity-80">{slogan}</h4>
        <h3 className="font-russo text-4xl uppercase leading-none text-stroke-white drop-shadow-md text-black">{title}</h3>
      </div>
      
      <p className="font-bold text-lg leading-tight border-t-4 border-black pt-4 mt-2">
        {description}
      </p>

      {/* Decorative corner */}
      <div className="absolute top-2 right-2 w-3 h-3 bg-black rounded-full"></div>
      <div className="absolute top-2 right-6 w-3 h-3 bg-white border-2 border-black rounded-full"></div>
    </div>
  );
};

export default LandingPage;